
import React from "react";
import ReactDOM from "react-dom";
import { Link } from "react-router-dom"
import 'bootstrap/dist/css/bootstrap.min.css';
//import "./styles.css";
import "./index.css"
import upanddown from "./images/upanddown.png";
import { candidates } from "./api/candidateapi"
import delete1 from "./images/delete.png";
import update from "./images/edit.png";
import { Button } from 'react-bootstrap';
/*function searchingFor(searchField) {
  return function (x) {
    return x.name.toLowerCase().includes(searchField.toLowerCase()) || !searchField

  }
}*/

class Employeelist extends React.Component {
  constructor(props) {
    super(props);
    this.state = {

      data: [],
    }

    //this.removeEmployee = this.removeEmployee.bind(this)
    //this.removeItem = this.removeItem.bind(this)
  }

  componentDidMount() {

    fetch(`http://localhost:8080/candidates`)

      .then(response => response.json())
      .then(users => this.setState({ data: users, }))
  }


  //}  data.push(data3)





  render() {
    const { data } = this.state;



    return (

      <div style={{ backgroundColor: "#FFFAFA" }}>

        <div className="jumbotron" style={{ backgroundColor: "#7B68EE", height: "300px", textAlign: "center", color: "white" }}>


        </div>
        <div className="container">
          <div> <h1>Candidates</h1></div><br></br>

          {/* First select */}

          <br></br>
          <table style={{ width: "100%" }}>

            <tr>
              <th style={{ width: "15%" }}>Fname<img src={upanddown} width="15" height="15" style={{ float: "right" }} />  </th>

              <th style={{ width: "15%" }}>Actions<img src={upanddown} width="15" height="15" style={{ float: "right" }} />  </th>



            </tr>
            {this.state.data.map(function (item, key) {
              return (

                <tr key={key}>

                  <td >{item.name}</td>

                  <td style={{ width: "160px" }}><button className="edit"> <img src={update} width="15" height="15" /><Link style={{ color: "white" }} to={item._id}>View </Link> </button>

                  </td>
                </tr>

              )
            })}

            <tr>
              {/*<th >Fname</th>

              <th> Action</th>*/}
            </tr>

          </table>
          showing 1 to  {this.state.data.length} entries
        <table></table>
        </div>
      </div >
    );
  }
}
export default Employeelist
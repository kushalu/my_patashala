import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import { candidate } from "./api/candidateapi"
import { Player, BigPlayButton } from 'video-react';
import 'bootstrap/dist/css/bootstrap.min.css';
class Getcandidate extends Component {
  constructor() {
    super()
    this.state = {
      id: "",
      empdata: [],
      error: ""
    }
  }
  init = canId => {
    //const token = isAuthenticated().token;
    candidate(canId).then(data => {
      console.log(data)
      if (data.error) {
        this.setState({ redirectToProfile: true });
      } else {
        this.setState({
          empdata: data,


        });

        console.log(this.setState.empdata)
      }
    });
    //
    //

  };



  componentDidMount() {
    //this.userData = new FormData();
    const canId = this.props.match.params.canId;
    //const name = this.state.name;
    //const n = this.state.name;
    //console.log(n)
    //console.log(name + "inside a component did mount")
    console.log(canId)
    this.init(canId);
    //this.com(canId);



  }

  /*handleChange = (comment) = event => {

    this.setState({ comment: event.taret.value })
  }
*/



  render() {

    return (
      <div >
        {this.state.empdata.map(function (item, key) {
          return (<div key={key}>
            <div style={{ marginLeft: "400px" }}>Name:{item.name}</div>
            <div>To watch a video please scroll down!!</div>
            <div> <Player>
              <source src={item.video} width="20" />

            </Player></div>

          </div>)
        })}
      </div>
    );


  }
}
export default Getcandidate
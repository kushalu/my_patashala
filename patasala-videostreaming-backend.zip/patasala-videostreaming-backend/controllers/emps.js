const Candidates = require("../models/candidates")


exports.candidateById = (req, res, next, id) => {
  Candidates.findById(id)
    // populate followers and following users array

    .exec((err, user) => {
      if (err || !user) {
        return res.status(400).json({
          error: "candidate not found"
        });
      }
      candidate = user;
      console.log("users" + user)
      // adds profile object in req with user info
      next();
    });

};
exports.Addcandidate = (req, res) => {

  const addcandidate = new Candidates(req.body)

  console.log(addcandidate)
  addcandidate.save((err, result) => {
    if (err) {
      return res.status(400).json({
        error: err
      })
    }
    else {
      res.status(200).json(

        result)
    }
  })

}





/*exports.getcandidates = (req, res) => {



}*/

exports.getCandidates = (req, res) => {
  //console.log(req.query.fname)



  Candidates.find()

    .exec((err, candidates) => {
      if (err) {
        return res.status(400).json({
          error: "Employees not found"
        })
      }

      res.json(candidates)
    })

};
exports.getCandidateid = (req, res) => {
  console
  // const cid = req.query.params
  const cid = candidate._id
  console.log("wow" + cid)
  Candidates.find({ _id: cid })

    .exec((err, candidates) => {
      if (err) {
        return res.status(400).json({
          error: "Employees not found"
        })
      }

      res.json(candidates)
    })

}





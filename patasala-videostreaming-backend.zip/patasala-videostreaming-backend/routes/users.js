const express = require("express");

const { Addcandidate, getCandidates, getCandidateid, candidateById, } = require("../controllers/emps")
const router = express.Router();


router.post("/addcandidate", Addcandidate)

router.get("/candidates", getCandidates)
router.get("/candidateid/:candId", getCandidateid)




router.param("candId", candidateById);


module.exports = router;

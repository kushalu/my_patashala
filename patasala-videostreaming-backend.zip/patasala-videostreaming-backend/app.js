


const express = require("express");
const app = express();
const mongoose = require("mongoose");

const bodyParser = require("body-parser");



const cors = require("cors");
const dotenv = require("dotenv");
dotenv.config();


mongoose.connect('mongodb://kushal:kushal123@ds139167.mlab.com:39167/my_patasala', { useNewUrlParser: true }/*)
  .then(() => console.log("DB Connected"));

mongoose.connection.on("error", err => {
  console.log(`DB connection error: ${err.message}`);
}*/
  , function (error) {
    if (error) {
      console.log(error)
    } else {
      console.log("connected to the database")
    }
  }
);

app.use(bodyParser.json());
// bring in routes
const userRoutes = require("./routes/users");


// middleware -



app.use(cors());

app.use("/", userRoutes);


app.use(function (err, req, res, next) {
  if (err.name === "UnauthorizedError") {
    res.status(401).json({ error: "Unauthorized!" });
  }
});

const port = process.env.PORT || 8080
app.listen(port, () => {
  console.log(`A Node Js API is listening on port: ${port}`);
});
